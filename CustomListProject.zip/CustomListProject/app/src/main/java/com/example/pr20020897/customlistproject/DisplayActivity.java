package com.example.pr20020897.customlistproject;

import android.Manifest;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    TextView name, bio, dob,spouse,height;
    ImageView pic;
    Player player ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        player = new Player();
        name = findViewById(R.id.name);
        bio = findViewById(R.id.bio);
        dob = findViewById(R.id.dob);
        spouse = findViewById(R.id.spouse);
        height = findViewById(R.id.height);
        pic = findViewById(R.id.image);

        Intent i = getIntent();
        int pos = i.getIntExtra("pos",0);
        name.setText(player.name[pos]);
        bio.setText(player.bio[pos]);
        dob.setText(player.dob[pos]);
        spouse.setText(player.Spouse[pos]);
        height.setText(player.height[pos]);
        pic.setImageResource(player.imageId[pos]);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        return super.onKeyDown(keyCode, event);
    }
}
